package com.autoaccess.controlplacas.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.autoaccess.controlplacas.data.dao.ResidentDao
import com.autoaccess.controlplacas.data.dao.VisitorDao
import com.autoaccess.controlplacas.data.model.Resident
import com.autoaccess.controlplacas.data.model.Visitor

@Database(entities = [Resident::class, Visitor::class], version = 1, exportSchema = false)
@TypeConverters(PlateConverters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun residentDao(): ResidentDao
    abstract fun visitorDao(): VisitorDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "auto_access_database.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
