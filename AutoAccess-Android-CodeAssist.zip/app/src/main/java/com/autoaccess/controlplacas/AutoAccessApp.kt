package com.autoaccess.controlplacas

import android.app.Application

class AutoAccessApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
