package com.autoaccess.controlplacas.util

import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern

object PlateUtils {

    /**
     * Limpia y normaliza una placa vehicular (mayúsculas y sólo alfanuméricos)
     */
    fun normalizePlate(raw: String): String {
        return raw.uppercase(Locale.getDefault())
            .replace("[^A-Z0-9]".toRegex(), "")
            .trim()
    }

    /**
     * Formatea una placa para visualización (ej: ABC-1234)
     */
    fun formatPlateDisplay(clean: String): String {
        val norm = normalizePlate(clean)
        if (norm.length in 6..7 && norm.take(3).all { it.isLetter() } && norm.drop(3).all { it.isDigit() }) {
            return norm.take(3) + "-" + norm.drop(3)
        }
        return norm
    }

    /**
     * Obtiene la hora y fecha exacta en la que se registra un visitante
     */
    fun getCurrentTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date())
    }

    /**
     * Extrae texto con patrón de placa vehicular a partir del texto de ML Kit
     */
    fun extractPlateCandidates(rawText: String): List<String> {
        val candidates = mutableListOf<String>()
        val upper = rawText.uppercase(Locale.getDefault())

        val patterns = listOf(
            Pattern.compile("\\b[A-Z]{3}[-\\s]?[0-9]{3,4}\\b"),
            Pattern.compile("\\b[0-9]{3}[-\\s]?[A-Z]{3}\\b"),
            Pattern.compile("\\b[A-Z]{2,4}[-\\s]?[0-9]{2,4}\\b")
        )

        for (pattern in patterns) {
            val matcher = pattern.matcher(upper)
            while (matcher.find()) {
                val found = matcher.group().replace("\\s+".toRegex(), "-")
                if (found.length in 5..9) {
                    candidates.add(found)
                }
            }
        }

        // Si no hubo coincidencia estricta, buscar tokens con letras y números
        if (candidates.isEmpty()) {
            val tokens = upper.split("[\\s\\n\\r,.:;]+".toRegex())
            for (token in tokens) {
                val clean = normalizePlate(token)
                if (clean.length in 5..8 && clean.any { it.isLetter() } && clean.any { it.isDigit() }) {
                    candidates.add(clean)
                }
            }
        }

        return candidates.distinct()
    }
}
