package com.autoaccess.controlplacas.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.autoaccess.controlplacas.data.database.PlateConverters

/**
 * Entidad de Residente / Propietario.
 * Puede almacenar MÚLTIPLES placas para una misma vivienda o persona.
 */
@Entity(tableName = "residents")
@TypeConverters(PlateConverters::class)
data class Resident(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val unit: String,             // Torre/Depto o Casa/Lote
    val phone: String,
    val plates: List<String>,      // Lista de placas vehiculares autorizadas
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
