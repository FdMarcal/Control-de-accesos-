package com.autoaccess.controlplacas.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.autoaccess.controlplacas.data.model.Resident

@Dao
interface ResidentDao {

    @Query("SELECT * FROM residents ORDER BY name ASC")
    fun getAllResidents(): LiveData<List<Resident>>

    @Query("SELECT * FROM residents ORDER BY name ASC")
    suspend fun getAllResidentsList(): List<Resident>

    @Query("SELECT * FROM residents WHERE id = :id LIMIT 1")
    suspend fun getResidentById(id: Long): Resident?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResident(resident: Resident): Long

    @Update
    suspend fun updateResident(resident: Resident)

    @Delete
    suspend fun deleteResident(resident: Resident)

    @Query("DELETE FROM residents WHERE id = :id")
    suspend fun deleteById(id: Long)
}
