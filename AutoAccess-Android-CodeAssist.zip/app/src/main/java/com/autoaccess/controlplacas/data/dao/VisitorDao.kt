package com.autoaccess.controlplacas.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.autoaccess.controlplacas.data.model.Visitor

@Dao
interface VisitorDao {

    @Query("SELECT * FROM visitors ORDER BY id DESC")
    fun getAllVisitors(): LiveData<List<Visitor>>

    @Query("SELECT * FROM visitors ORDER BY id DESC")
    suspend fun getAllVisitorsList(): List<Visitor>

    @Query("SELECT * FROM visitors WHERE status = 'DENTRO' ORDER BY id DESC")
    fun getActiveVisitors(): LiveData<List<Visitor>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVisitor(visitor: Visitor): Long

    @Update
    suspend fun updateVisitor(visitor: Visitor)

    @Delete
    suspend fun deleteVisitor(visitor: Visitor)

    @Query("DELETE FROM visitors WHERE id = :id")
    suspend fun deleteById(id: Long)
}
