package com.autoaccess.controlplacas.data.database

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Conversor Room para persistir la lista de placas vehiculares (List<String>)
 */
class PlateConverters {
    private val gson = Gson()

    @TypeConverter
    fun fromPlateList(plates: List<String>?): String {
        if (plates == null) return "[]"
        return gson.toJson(plates)
    }

    @TypeConverter
    fun toPlateList(data: String?): List<String> {
        if (data.isNullOrEmpty()) return emptyList()
        val listType = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(data, listType)
    }
}
