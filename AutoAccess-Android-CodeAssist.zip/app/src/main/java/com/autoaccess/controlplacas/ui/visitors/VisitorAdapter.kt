package com.autoaccess.controlplacas.ui.visitors

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.autoaccess.controlplacas.R
import com.autoaccess.controlplacas.data.model.Visitor

class VisitorAdapter(
    private val onEdit: (Visitor) -> Unit,
    private val onDelete: (Visitor) -> Unit
) : ListAdapter<Visitor, VisitorAdapter.ViewHolder>(DiffCallback) {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvVisitorName)
        val tvDest: TextView = view.findViewById(R.id.tvVisitorDest)
        val tvPlate: TextView = view.findViewById(R.id.tvVisitorPlate)
        val tvTimestamp: TextView = view.findViewById(R.id.tvVisitorTimestamp)
        val tvStatus: TextView = view.findViewById(R.id.tvVisitorStatus)
        val btnEdit: Button = view.findViewById(R.id.btnEditVisitor)
        val btnDelete: Button = view.findViewById(R.id.btnDeleteVisitor)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_visitor, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.tvName.text = item.name
        holder.tvDest.text = "Destino: ${item.destinationUnit}"
        holder.tvPlate.text = item.plate
        holder.tvTimestamp.text = "Entrada: ${item.entryTimestamp}"
        holder.tvStatus.text = item.status

        holder.btnEdit.setOnClickListener { onEdit(item) }
        holder.btnDelete.setOnClickListener { onDelete(item) }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Visitor>() {
        override fun areItemsTheSame(oldItem: Visitor, newItem: Visitor) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Visitor, newItem: Visitor) = oldItem == newItem
    }
}
