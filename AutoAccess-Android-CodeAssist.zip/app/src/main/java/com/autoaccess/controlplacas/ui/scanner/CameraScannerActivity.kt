package com.autoaccess.controlplacas.ui.scanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.autoaccess.controlplacas.data.database.AppDatabase
import com.autoaccess.controlplacas.data.model.Resident
import com.autoaccess.controlplacas.databinding.ActivityCameraScannerBinding
import com.autoaccess.controlplacas.util.PlateUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraScannerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCameraScannerBinding
    private lateinit var cameraExecutor: ExecutorService
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var isProcessing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.btnBack.setOnClickListener { finish() }

        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_CODE
            )
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
            }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        processImageProxy(imageProxy)
                    }
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalyzer)
            } catch (exc: Exception) {
                Toast.makeText(this, "Error al iniciar la cámara: ${exc.message}", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    private fun processImageProxy(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null || isProcessing) {
            imageProxy.close()
            return
        }

        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        textRecognizer.process(image)
            .addOnSuccessListener { visionText ->
                val detectedCandidates = PlateUtils.extractPlateCandidates(visionText.text)
                if (detectedCandidates.isNotEmpty() && !isProcessing) {
                    val plate = detectedCandidates.first()
                    runOnUiThread {
                        binding.tvDetectedPlate.text = "Placa detectada: $plate"
                    }
                    verifyPlateInDatabase(plate)
                }
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    private fun verifyPlateInDatabase(rawPlate: String) {
        isProcessing = true
        val normalized = PlateUtils.normalizePlate(rawPlate)

        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(applicationContext)
            val allResidents = db.residentDao().getAllResidentsList()

            // Buscar si pertenece a alguien de la lista de propietarios/residentes
            val residentMatch: Resident? = allResidents.find { res ->
                res.plates.any { PlateUtils.normalizePlate(it) == normalized }
            }

            withContext(Dispatchers.Main) {
                if (residentMatch != null) {
                    // PERTENECE A UN RESIDENTE (PROPIETARIO)
                    showResidentMatchDialog(rawPlate, residentMatch)
                } else {
                    // NO SE ENCUENTRA EN LA LISTA DE PROPIETARIOS
                    showNotFoundDialog(rawPlate)
                }
            }
        }
    }

    private fun showResidentMatchDialog(plate: String, resident: Resident) {
        AlertDialog.Builder(this)
            .setTitle("✅ VEHÍCULO DE RESIDENTE")
            .setMessage("La placa '$plate' pertenece al Propietario:

" +
                    "Nombre: ${resident.name}
" +
                    "Unidad/Depto: ${resident.unit}
" +
                    "Teléfono: ${resident.phone}
" +
                    "Placas registradas: ${resident.plates.joinToString(", ")}")
            .setPositiveButton("Permitir Acceso") { dialog, _ ->
                dialog.dismiss()
                isProcessing = false
            }
            .setNeutralButton("Continuar Escaneando") { dialog, _ ->
                dialog.dismiss()
                isProcessing = false
            }
            .setCancelable(false)
            .show()
    }

    private fun showNotFoundDialog(plate: String) {
        AlertDialog.Builder(this)
            .setTitle("⚠️ PLACA NO REGISTRADA EN PROPIETARIOS")
            .setMessage("La placa '$plate' NO pertenece a ningún residente registrado.

" +
                    "¿Desea registrarla en la lista de Visitantes (capturando la hora actual) o asignarla a un Residente?")
            .setPositiveButton("Registrar como Visitante") { dialog, _ ->
                dialog.dismiss()
                val intent = Intent()
                intent.putExtra("ACTION", "REGISTER_VISITOR")
                intent.putExtra("PLATE", plate)
                intent.putExtra("TIMESTAMP", PlateUtils.getCurrentTimestamp())
                setResult(RESULT_OK, intent)
                finish()
            }
            .setNegativeButton("Asignar a Residente") { dialog, _ ->
                dialog.dismiss()
                val intent = Intent()
                intent.putExtra("ACTION", "ASSIGN_TO_RESIDENT")
                intent.putExtra("PLATE", plate)
                setResult(RESULT_OK, intent)
                finish()
            }
            .setNeutralButton("Reintentar") { dialog, _ ->
                dialog.dismiss()
                isProcessing = false
            }
            .setCancelable(false)
            .show()
    }

    private fun allPermissionsGranted() = ContextCompat.checkSelfPermission(
        baseContext, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this, "Permiso de cámara denegado", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    companion object {
        private const val CAMERA_PERMISSION_CODE = 101
    }
}
