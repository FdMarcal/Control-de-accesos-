package com.autoaccess.controlplacas.ui.residents

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.autoaccess.controlplacas.R
import com.autoaccess.controlplacas.data.model.Resident

class ResidentAdapter(
    private val onEdit: (Resident) -> Unit,
    private val onDelete: (Resident) -> Unit
) : ListAdapter<Resident, ResidentAdapter.ViewHolder>(DiffCallback) {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvResidentName)
        val tvUnit: TextView = view.findViewById(R.id.tvResidentUnit)
        val tvPhone: TextView = view.findViewById(R.id.tvResidentPhone)
        val tvPlates: TextView = view.findViewById(R.id.tvResidentPlates)
        val btnEdit: Button = view.findViewById(R.id.btnEditResident)
        val btnDelete: Button = view.findViewById(R.id.btnDeleteResident)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_resident, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.tvName.text = item.name
        holder.tvUnit.text = item.unit
        holder.tvPhone.text = if (item.phone.isNotEmpty()) "Tel: ${item.phone}" else "Sin teléfono"
        holder.tvPlates.text = if (item.plates.isNotEmpty()) "Placas (${item.plates.size}): ${item.plates.joinToString(", ")}" else "Sin placas registradas"

        holder.btnEdit.setOnClickListener { onEdit(item) }
        holder.btnDelete.setOnClickListener { onDelete(item) }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Resident>() {
        override fun areItemsTheSame(oldItem: Resident, newItem: Resident) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Resident, newItem: Resident) = oldItem == newItem
    }
}
