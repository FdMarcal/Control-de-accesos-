package com.autoaccess.controlplacas

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.autoaccess.controlplacas.data.database.AppDatabase
import com.autoaccess.controlplacas.data.model.Resident
import com.autoaccess.controlplacas.data.model.Visitor
import com.autoaccess.controlplacas.databinding.ActivityMainBinding
import com.autoaccess.controlplacas.ui.residents.ResidentAdapter
import com.autoaccess.controlplacas.ui.scanner.CameraScannerActivity
import com.autoaccess.controlplacas.ui.visitors.VisitorAdapter
import com.autoaccess.controlplacas.util.PlateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var database: AppDatabase
    private lateinit var residentAdapter: ResidentAdapter
    private lateinit var visitorAdapter: VisitorAdapter

    private var currentTab = 0 // 0 = Residentes, 1 = Visitantes

    private val scannerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val action = result.data?.getStringExtra("ACTION")
            val plate = result.data?.getStringExtra("PLATE") ?: ""
            val timestamp = result.data?.getStringExtra("TIMESTAMP") ?: PlateUtils.getCurrentTimestamp()

            if (action == "REGISTER_VISITOR") {
                showAddVisitorDialog(prefilledPlate = plate, prefilledTimestamp = timestamp)
            } else if (action == "ASSIGN_TO_RESIDENT") {
                showAssignPlateToResidentDialog(plate)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)
        setupRecyclerViews()
        setupListeners()
        observeData()
    }

    private fun setupRecyclerViews() {
        residentAdapter = ResidentAdapter(
            onEdit = { resident -> showEditResidentDialog(resident) },
            onDelete = { resident -> confirmDeleteResident(resident) }
        )
        binding.rvResidents.layoutManager = LinearLayoutManager(this)
        binding.rvResidents.adapter = residentAdapter

        visitorAdapter = VisitorAdapter(
            onEdit = { visitor -> showEditVisitorDialog(visitor) },
            onDelete = { visitor -> confirmDeleteVisitor(visitor) }
        )
        binding.rvVisitors.layoutManager = LinearLayoutManager(this)
        binding.rvVisitors.adapter = visitorAdapter
    }

    private fun setupListeners() {
        binding.tabResidents.setOnClickListener { switchTab(0) }
        binding.tabVisitors.setOnClickListener { switchTab(1) }

        binding.btnScanCamera.setOnClickListener {
            val intent = Intent(this, CameraScannerActivity::class.java)
            scannerLauncher.launch(intent)
        }

        binding.btnAdd.setOnClickListener {
            if (currentTab == 0) {
                showAddResidentDialog()
            } else {
                showAddVisitorDialog()
            }
        }
    }

    private fun switchTab(tabIndex: Int) {
        currentTab = tabIndex
        if (tabIndex == 0) {
            binding.rvResidents.visibility = android.view.View.VISIBLE
            binding.rvVisitors.visibility = android.view.View.GONE
            binding.btnAdd.text = "+ Nuevo Residente"
            binding.tabResidents.setBackgroundColor(getColor(R.color.primary))
            binding.tabVisitors.setBackgroundColor(getColor(R.color.surface))
        } else {
            binding.rvResidents.visibility = android.view.View.GONE
            binding.rvVisitors.visibility = android.view.View.VISIBLE
            binding.btnAdd.text = "+ Nuevo Visitante"
            binding.tabVisitors.setBackgroundColor(getColor(R.color.primary))
            binding.tabResidents.setBackgroundColor(getColor(R.color.surface))
        }
    }

    private fun observeData() {
        database.residentDao().getAllResidents().observe(this) { list ->
            residentAdapter.submitList(list)
            binding.tvResidentCount.text = "${list.size} Residentes"
        }

        database.visitorDao().getAllVisitors().observe(this) { list ->
            visitorAdapter.submitList(list)
            binding.tvVisitorCount.text = "${list.size} Visitantes"
        }
    }

    // DIÁLOGOS DE RESIDENTE (Múltiples placas)
    private fun showAddResidentDialog(prefilledPlate: String = "") {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_resident, null)
        val etName = view.findViewById<EditText>(R.id.etResidentName)
        val etUnit = view.findViewById<EditText>(R.id.etResidentUnit)
        val etPhone = view.findViewById<EditText>(R.id.etResidentPhone)
        val etPlates = view.findViewById<EditText>(R.id.etResidentPlates)

        if (prefilledPlate.isNotEmpty()) {
            etPlates.setText(prefilledPlate)
        }

        AlertDialog.Builder(this)
            .setTitle("Registrar Residente (Propietario)")
            .setView(view)
            .setPositiveButton("Guardar") { _, _ ->
                val name = etName.text.toString().trim()
                val unit = etUnit.text.toString().trim()
                val phone = etPhone.text.toString().trim()
                val platesRaw = etPlates.text.toString().trim()

                if (name.isNotEmpty() && unit.isNotEmpty()) {
                    val platesList = platesRaw.split("[,\\s]+".toRegex())
                        .map { PlateUtils.formatPlateDisplay(it) }
                        .filter { it.isNotEmpty() }

                    val newResident = Resident(
                        name = name,
                        unit = unit,
                        phone = phone,
                        plates = platesList
                    )
                    lifecycleScope.launch(Dispatchers.IO) {
                        database.residentDao().insertResident(newResident)
                    }
                } else {
                    Toast.makeText(this, "El nombre y departamento son requeridos", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showEditResidentDialog(resident: Resident) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_resident, null)
        val etName = view.findViewById<EditText>(R.id.etResidentName)
        val etUnit = view.findViewById<EditText>(R.id.etResidentUnit)
        val etPhone = view.findViewById<EditText>(R.id.etResidentPhone)
        val etPlates = view.findViewById<EditText>(R.id.etResidentPlates)

        etName.setText(resident.name)
        etUnit.setText(resident.unit)
        etPhone.setText(resident.phone)
        etPlates.setText(resident.plates.joinToString(", "))

        AlertDialog.Builder(this)
            .setTitle("Editar Residente")
            .setView(view)
            .setPositiveButton("Actualizar") { _, _ ->
                val name = etName.text.toString().trim()
                val unit = etUnit.text.toString().trim()
                val phone = etPhone.text.toString().trim()
                val platesRaw = etPlates.text.toString().trim()

                val platesList = platesRaw.split("[,\\s]+".toRegex())
                    .map { PlateUtils.formatPlateDisplay(it) }
                    .filter { it.isNotEmpty() }

                val updated = resident.copy(
                    name = name,
                    unit = unit,
                    phone = phone,
                    plates = platesList
                )
                lifecycleScope.launch(Dispatchers.IO) {
                    database.residentDao().updateResident(updated)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDeleteResident(resident: Resident) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar Residente")
            .setMessage("¿Seguro que desea eliminar a ${resident.name}? Se borrarán todas sus placas asociadas.")
            .setPositiveButton("Eliminar") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    database.residentDao().deleteResident(resident)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // DIÁLOGOS DE VISITANTE (Captura automática de hora)
    private fun showAddVisitorDialog(prefilledPlate: String = "", prefilledTimestamp: String = "") {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_visitor, null)
        val etName = view.findViewById<EditText>(R.id.etVisitorName)
        val etUnit = view.findViewById<EditText>(R.id.etVisitorUnit)
        val etPlate = view.findViewById<EditText>(R.id.etVisitorPlate)
        val etTime = view.findViewById<EditText>(R.id.etVisitorTimestamp)

        val timestamp = if (prefilledTimestamp.isNotEmpty()) prefilledTimestamp else PlateUtils.getCurrentTimestamp()
        etTime.setText(timestamp)
        etTime.isEnabled = false

        if (prefilledPlate.isNotEmpty()) {
            etPlate.setText(prefilledPlate)
        }

        AlertDialog.Builder(this)
            .setTitle("Registrar Visitante")
            .setView(view)
            .setPositiveButton("Registrar Ingreso") { _, _ ->
                val name = etName.text.toString().trim()
                val unit = etUnit.text.toString().trim()
                val plate = etPlate.text.toString().trim()

                if (name.isNotEmpty() && plate.isNotEmpty()) {
                    val visitor = Visitor(
                        name = name,
                        destinationUnit = unit,
                        plate = PlateUtils.formatPlateDisplay(plate),
                        entryTimestamp = timestamp,
                        status = "DENTRO"
                    )
                    lifecycleScope.launch(Dispatchers.IO) {
                        database.visitorDao().insertVisitor(visitor)
                    }
                } else {
                    Toast.makeText(this, "Nombre y placa son obligatorios", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showEditVisitorDialog(visitor: Visitor) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_visitor, null)
        val etName = view.findViewById<EditText>(R.id.etVisitorName)
        val etUnit = view.findViewById<EditText>(R.id.etVisitorUnit)
        val etPlate = view.findViewById<EditText>(R.id.etVisitorPlate)
        val etTime = view.findViewById<EditText>(R.id.etVisitorTimestamp)

        etName.setText(visitor.name)
        etUnit.setText(visitor.destinationUnit)
        etPlate.setText(visitor.plate)
        etTime.setText(visitor.entryTimestamp)

        AlertDialog.Builder(this)
            .setTitle("Editar Visitante")
            .setView(view)
            .setPositiveButton("Guardar") { _, _ ->
                val updated = visitor.copy(
                    name = etName.text.toString().trim(),
                    destinationUnit = etUnit.text.toString().trim(),
                    plate = PlateUtils.formatPlateDisplay(etPlate.text.toString().trim())
                )
                lifecycleScope.launch(Dispatchers.IO) {
                    database.visitorDao().updateVisitor(updated)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDeleteVisitor(visitor: Visitor) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar Registro")
            .setMessage("¿Desea eliminar el registro de ${visitor.name} (Placa: ${visitor.plate})?")
            .setPositiveButton("Eliminar") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    database.visitorDao().deleteVisitor(visitor)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showAssignPlateToResidentDialog(newPlate: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            val residents = database.residentDao().getAllResidentsList()
            withContext(Dispatchers.Main) {
                if (residents.isEmpty()) {
                    Toast.makeText(this@MainActivity, "No hay residentes registrados. Agregue uno primero.", Toast.LENGTH_LONG).show()
                    showAddResidentDialog(prefilledPlate = newPlate)
                    return@withContext
                }

                val names = residents.map { "${it.name} (${it.unit})" }.toTypedArray()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Asignar Placa '$newPlate' a Residente")
                    .setItems(names) { _, which ->
                        val selectedResident = residents[which]
                        val updatedPlates = selectedResident.plates.toMutableList()
                        if (!updatedPlates.contains(newPlate)) {
                            updatedPlates.add(newPlate)
                        }
                        lifecycleScope.launch(Dispatchers.IO) {
                            database.residentDao().updateResident(selectedResident.copy(plates = updatedPlates))
                        }
                        Toast.makeText(this@MainActivity, "Placa agregada a ${selectedResident.name}", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }
}
