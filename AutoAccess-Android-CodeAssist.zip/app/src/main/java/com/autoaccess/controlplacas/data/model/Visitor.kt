package com.autoaccess.controlplacas.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidad de Visitante.
 * Captura automáticamente la hora y fecha en la que se agregó el individuo y su placa.
 */
@Entity(tableName = "visitors")
data class Visitor(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val destinationUnit: String,  // Unidad a la que se dirige
    val plate: String,            // Placa del vehículo visitante
    val vehicleDescription: String = "",
    val entryTimestamp: String,   // Hora y fecha exacta registrada (ej: "2026-10-07 15:30:00")
    val exitTimestamp: String? = null,
    val status: String = "DENTRO", // "DENTRO" o "SALIO"
    val notes: String = ""
)
